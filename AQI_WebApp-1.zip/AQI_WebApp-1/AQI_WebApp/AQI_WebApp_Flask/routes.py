from AQI_WebApp_Flask import app, forms
from flask import request, render_template

@app.route('/', methods=['GET','POST'])
def search():
    searchForm = forms.AQIParameters(request.form)
    if request.method == "POST":

        '''
        If the user makes a post request, please save the selected value by the user into a variable
        Also, call the function aqi_parameter (from forms.py) with all the results
        Then, render template parameter_result.html only with the parameter requested by the user
        Which means that you should assign the correct value for the variable parameter_requested below
        '''

        # this gives what's in select field, returns left side value
        aqiparameter = request.form['aqiparameter']

        # function in forms.py returns a dictionary
        parameters = forms.aqi_parameter()

        for i in parameters:
            # gives me keys in parameters: print(i)
            if aqiparameter == i:
                requestedValue = parameters[i]
                # ex. above is same as (parameters['temperatureC'])

                if 'temperatureC' == i:
                    valueUnit = '°'

                elif 'pressure' == i:
                    valueUnit = 'mb'

                elif 'humidity' == i:
                    valueUnit = '%'

                else:
                    valueUnit = ''

        parameter_requested = requestedValue
        parameter_unit = valueUnit

        return render_template('parameter_result.html', result=parameter_requested, resultUnit = parameter_unit)
    return render_template('parameter_search.html', form=searchForm)