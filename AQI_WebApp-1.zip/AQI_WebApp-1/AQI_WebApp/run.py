# By: Jennifer Moreno
# Panther ID: 5775423

from AQI_WebApp_Flask import app, forms

if __name__ == '__main__':
    app.run()





