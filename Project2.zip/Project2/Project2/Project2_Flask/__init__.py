from flask import Flask

app = Flask(__name__)

app.config["SECRET_KEY"] = "project_2_using_flask"

from Project2_Flask import routes
