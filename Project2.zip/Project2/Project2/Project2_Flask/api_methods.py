from Project2_Flask import main_functions
import requests

def request_key():
    apiDict = main_functions.read_from_file("Project2_Flask/JSON_Files/api_keys.json")
    return apiDict['my_key']

def search(aTitle, aSort, aCheckedBox):
    if aSort == "publicationDate":
        if aCheckedBox == 'y':
            url = "https://api.nytimes.com/svc/movies/v2/reviews/search.json?critics-pick=Y&order=by-publication-date&query=" + aTitle + "&api-key=" + request_key()
        elif aCheckedBox == 'n':
            url = "https://api.nytimes.com/svc/movies/v2/reviews/search.json?order=by-publication-date&query=" + aTitle + "&api-key=" + request_key()
    else:
        if aCheckedBox == 'y':
            url = "https://api.nytimes.com/svc/movies/v2/reviews/search.json?critics-pick=Y&order=by-opening-date&query=" + aTitle + "&api-key=" + request_key()
        elif aCheckedBox == 'n':
            url = "https://api.nytimes.com/svc/movies/v2/reviews/search.json?order=by-opening-date&query=" + aTitle + "&api-key=" + request_key()

    response = requests.get(url).json()

    main_functions.save_to_file(response,"Project2_Flask/JSON_Files/api.json")
    return response


#Search for a title with string and use radio button to sort results
#requestUrl = "https://api.nytimes.com/svc/movies/v2/reviews/search.json?order=by-opening-date&query=" + aTitle + "&api-key=" + request_key()
#requestUrl = "https://api.nytimes.com/svc/movies/v2/reviews/search.json?order=by-publication-date&query=" + aTitle +"&api-key=" + request_key()

