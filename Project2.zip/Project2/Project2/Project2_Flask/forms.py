#from Project2_Flask import app
from flask_wtf import FlaskForm
from wtforms import StringField,BooleanField, RadioField

class ReviewForms(FlaskForm):
    searchTitle = StringField('Search Title')
    sortBy = RadioField('Sort By', choices=[('publicationDate','Review publication date'),
                                            ('openingDate','Movie U.S. opening date')],
                        default='publicationDate')
    criticsPicks = BooleanField('Critics Picks')



