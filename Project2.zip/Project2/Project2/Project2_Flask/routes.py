from Project2_Flask import app,forms,api_methods
from flask import request, render_template

@app.route('/', methods=["GET","POST"])
def movieReviews():
    my_review_form = forms.ReviewForms(request.form)

    if request.method == "POST":
        searchTitle = request.form['searchTitle']
        sortBy = request.form['sortBy']
        #criticsPicks = request.form['criticsPicks']

        if 'criticsPicks' in request.form:
            criticsPicks = 'y'
        else:
            criticsPicks = 'n'

        searchResults = api_methods.search(searchTitle, sortBy, criticsPicks)

        lst_results = []

        if searchResults["results"] is None:
            message = "No results were found for your entry, please try a different one."
            return render_template("noResultsFound.html", message=message)
        else:
            for i in searchResults["results"]:
                resultInformation = (i["display_title"], i["opening_date"], i["byline"], i["summary_short"], i["publication_date"], i["link"]["url"], i["link"]["suggested_link_text"])
                lst_results.append(resultInformation)
            return render_template("results.html", response=lst_results)
    return render_template("search.html", form=my_review_form)


