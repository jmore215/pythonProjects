#By: Jennifer Moreno
#Panther ID: 5775423

from Project2_Flask import app

if __name__ == '__main__':
    app.run(debug=True, port=5050)

