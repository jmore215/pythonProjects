# By: Jennifer Moreno
# PID: 5775423

from flask import Flask, render_template, request, url_for
from flask_pymongo import PyMongo
from flask_wtf import FlaskForm
from wtforms import StringField, DateField, SelectField, DecimalField
import requests, main_functions
#pip install Flask Flask-PyMongo Flask-WTF wtforms dnspython

app = Flask(__name__)

app.config["SECRET_KEY"] = "very strong secret key"
app.config["MONGO_URI"] = "mongodb+srv://test_user:test_user@cluster0.1frsx.mongodb.net/db?retryWrites=true&w=majority"

mongo = PyMongo(app)

class Expenses(FlaskForm):
    # you need to complete the form for the following fields:
    # StringField for description
    description = StringField('Description')
    # SelectField for category
    category = SelectField('Category', choices=[("rent","Rent"),
                                                ("electricity","Electricity"),
                                                ("water","Water"),
                                                ("internet","Internet"),
                                                ("insurance","Insurance"),
                                                ("restaurants","Restaurants"),
                                                ("groceries","Groceries"),
                                                ("gas","Gas"),
                                                ("college","College"),
                                                ("party","Party"),
                                                ("mortgage","Mortgage")])
    # DecimalField for cost
    cost = DecimalField("Cost")

    # SelectField for currency
    currency = SelectField("Currency", choices=[("USD","US Dollar"),
                                                ("BRL","Brazilian Real"),
                                                ("BTC","Bitcoin"),
                                                ("CAD","Canadian Dollar"),
                                                ("COP","Colombian Peso"),
                                                ("EUR","Euro"),
                                                ("GBP","British Pound Sterling")])

    # DateField for date
    date = DateField("Date", format='%m/%d/%Y')


def currency_converter(cost, currency):
    url = "http://api.currencylayer.com/live?access_key=f7c17e3a149f5b0529fb55538ca6da6b"
    response = requests.get(url).json()

    main_functions.save_to_file(response, "response.json")

    currencyKey = "USD" + currency

    conversionRate = response['quotes'][currencyKey]

    converted_cost = float(cost) / conversionRate

    return converted_cost


def get_total_expenses(category):
    # Access the database adding the cost of all documents
    # of the category passed as input parameter
    # write the appropriate query to retrieve the cost
    queryCategory = {"category":category}

    totalCostByCategory = 0

    queryCategoryResults = mongo.db.expenses.find(queryCategory)

    for i in queryCategoryResults:
        totalCostByCategory += float(i["cost"])

    return round(totalCostByCategory, 2)


@app.route('/')
def index():
    my_expenses = mongo.db.expenses.find()
    total_cost = 0
    for i in my_expenses:
        total_cost += float(i["cost"])
    expensesByCategory = [
        ("rent",get_total_expenses("rent")),
        ("electricity", get_total_expenses("electricity")),
        ("water", get_total_expenses("water")),
        ("internet", get_total_expenses("internet")),
        ("insurance", get_total_expenses("insurance")),
        ("restaurants", get_total_expenses("restaurants")),
        ("groceries", get_total_expenses("groceries")),
        ("gas", get_total_expenses("gas")),
        ("college", get_total_expenses("college")),
        ("party", get_total_expenses("party")),
        ("mortgage", get_total_expenses("mortgage"))
    ]

    return render_template("index.html", expenses=round(total_cost, 2), expensesByCategory=expensesByCategory)


@app.route('/addExpenses', methods=["GET","POST"])
def addExpenses():
    #INCLUDE THE FORM BASED ON class Expenses
    expensesForm = Expenses(request.form)

    if request.method == "POST":
        # INSERT ONE DOCUMENT TO THE DATABASE
        # CONTAINING THE DATA LOGGED BY THE USER
        # REMEMBER THAT IT SHOULD BE A PYTHON DICTIONARY
        description = request.form['description']
        category = request.form['category']
        cost = request.form['cost']
        currency = request.form['currency']
        date = request.form['date']

        costUSD = 0

        if currency == 'USD':
            costUSD = float(cost)
        else:
            costUSD = round(currency_converter(cost,currency), 2)

        anExpense = {'description':description,
                     'category':category,
                     'cost':costUSD,
                     'date':date}

        mongo.db.expenses.insert_one(anExpense)

        return render_template("expenseAdded.html")
    return render_template("addExpenses.html", form=expensesForm)

app.run()
